#!/bin/sh
tar cvf pariemacs-3.05.tar Makefile pari.el pari-completion.el pari-conf.el.in pariemacs-3.05.txt pari-fontification.el pari-help.el pari-history.el pari-messages.el sli-tools.el maketarfile.sh

gzip -9 pariemacs-3.05.tar
exit 0
